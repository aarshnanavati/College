from Tkinter import *
import tkMessageBox
import Tkinter

#create a new window
window = Tkinter.Tk()
window.geometry("300x300")
var = IntVar()
c = Checkbutton(window, text="Expand", variable=var, onvalue="1", offvalue="0")
c.select()
c.pack()
window.mainloop()