#import the 'tkinter' module
import Tkinter
import Tkinter as tkinter
#create a new window
window = tkinter.Tk()
#draw the window, and start the 'application'
window.mainloop()